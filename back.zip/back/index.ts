import express from 'express';
import cors from 'cors';
import mongoose from 'mongoose';
import Event from './models/Event';

const app = express();
const PORT = process.env.PORT || 3001;
const ITEMS_PER_PAGE = 6;

// Middleware
app.use(cors());
app.use(express.json());

// MongoDB connection
mongoose.connect('mongodb://localhost:27017/webi')
  .then(() => console.log('Connected to MongoDB'))
  .catch((err) => console.error('MongoDB connection error:', err));

// Routes
app.get('/api/events', async (req, res) => {
  try {
    const page = parseInt(req.query.page as string) || 1;
    const skip = (page - 1) * ITEMS_PER_PAGE;
    
    const [events, total] = await Promise.all([
      Event.find()
        .sort({ date: -1 })
        .skip(skip)
        .limit(ITEMS_PER_PAGE),
      Event.countDocuments()
    ]);

    res.json({
      events,
      total,
      totalPages: Math.ceil(total / ITEMS_PER_PAGE),
      currentPage: page,
      itemsPerPage: ITEMS_PER_PAGE
    });
  } catch (error) {
    console.error('Error fetching events:', error);
    res.status(500).json({ error: 'Failed to fetch events' });
  }
});

app.get('/api/events/:id', async (req, res) => {
  try {
    const event = await Event.findById(req.params.id);
    if (!event) {
      return res.status(404).json({ error: 'Event not found' });
    }
    res.json(event);
  } catch (error) {
    console.error('Error fetching event:', error);
    res.status(500).json({ error: 'Failed to fetch event' });
  }
});

app.post('/api/events', async (req, res) => {
  try {
    const event = new Event({
      ...req.body,
      date: new Date(req.body.date),
    });
    await event.save();
    res.status(201).json(event);
  } catch (error) {
    console.error('Error creating event:', error);
    res.status(500).json({ error: 'Failed to create event' });
  }
});

// Start server
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
